
RAWImaging

********************************************************************************
**  This program is free software; you can redistribute it and/or modify      **
**  it under the terms of the GNU General Public License as published by      **
**  the Free Software Foundation; either version 2 of the License, or         **
**  (at your option) any later version.                                       **
**                                                                            **
**  This program is distributed in the hope that it will be useful,           **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of            **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             **
**  GNU General Public License for more details.                              **
**                                                                            **
**  You should have received a copy of the GNU General Public License         **
**  along with this program; if not, write to the Free Software               ** 
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA **
********************************************************************************
**                                                                            **
**  For more details about license see the file COPYING.                      **
**                                                                            **
********************************************************************************

Forensic (but not only) graphical frontend to work with binary images (RAW) of media in GNU/Linux. These images are universal and can be installed using both standard operating systems and popular forensic software such as Encase, Sleuthkit/Autopsy, etc. in all operating systems).
The idea of the project is to implement a fast, convenient and safe making of legal copies and manipulating with images, by means of GNU/Linux, without the need for expensive hardware write lock on the media, it is necessary in the existing solutions under Windows. Also the program can be used as a last chance to rescue data from a dying media by software.

********************************************************************************

Features:
- The interface is designed in such a way as to minimize the possibility of data loss when used as a result of user's error or hardware failure. In this case the program is transparent to those who used to work manually on the command line.
- Copy the contents of the hard disk image file by means of a popular tool dd_rescue, which allows to obtain a copy of even heavily damaged media.
- Automatic resume after the break up, for example, in case of loss of a disk or hardware failure. This further increases the chance to make a copy of the damaged disk in case of degradation during the second reading, or just save time.
- Calculation MD5 and SHA1 checksums of the image captured.
- Ability to deploy the image file on a physical medium. This allows the drive to return the modified data to its original state, run the OS from the image file on a physical PC, completely transfer the data to other media, etc.
- Easy to mount and unmount partitions with data of image file.
- The program can be easily integrated into the Live CD.
- Available build for qt and gtk both.

********************************************************************************

Information on how to install and use the software is contained in a file INSTALL.
